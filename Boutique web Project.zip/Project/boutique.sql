-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 13, 2017 at 05:53 PM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `boutique`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_to_cart`
--

CREATE TABLE `add_to_cart` (
  `Reg_id` int(6) NOT NULL,
  `Pro_id` int(5) NOT NULL,
  `Size` varchar(30) NOT NULL,
  `Quantity` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_to_cart`
--

INSERT INTO `add_to_cart` (`Reg_id`, `Pro_id`, `Size`, `Quantity`) VALUES
(24, 26, 'Medium', '1'),
(20, 35, ',Small,Medium,Large', ',20,10,5');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `Cat_id` int(3) NOT NULL,
  `Cat_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`Cat_id`, `Cat_name`) VALUES
(1, 'Casual'),
(2, 'Formal'),
(3, 'Sport'),
(4, 'Trendy');

-- --------------------------------------------------------

--
-- Table structure for table `delivery_details`
--

CREATE TABLE `delivery_details` (
  `order_id` int(5) NOT NULL,
  `fname` varchar(15) NOT NULL,
  `lname` varchar(15) NOT NULL,
  `contact` char(10) NOT NULL,
  `address` varchar(50) NOT NULL,
  `city` varchar(15) NOT NULL,
  `zipcode` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delivery_details`
--

INSERT INTO `delivery_details` (`order_id`, `fname`, `lname`, `contact`, `address`, `city`, `zipcode`) VALUES
(55, 'Jill', 'Patel', '9574418220', '3,Vishnu Ram Society;', 'Nadiad', 354789),
(56, 'Chintan', 'Gandhi', '9978811646', '3,MohanKrupa Society;\r\nNear Jain Temple;\r\nManjalpu', 'Vadodara', 390011);

-- --------------------------------------------------------

--
-- Table structure for table `eventmst`
--

CREATE TABLE `eventmst` (
  `EventId` int(3) NOT NULL,
  `CatId` int(3) NOT NULL,
  `StartMon` int(2) NOT NULL,
  `EndMon` int(2) NOT NULL,
  `EventName` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `eventmst`
--

INSERT INTO `eventmst` (`EventId`, `CatId`, `StartMon`, `EndMon`, `EventName`) VALUES
(4, 1, 4, 7, 'Summer Sale'),
(5, 2, 8, 9, 'Monsoon Sale'),
(6, 1, 12, 2, 'Wedding Sale');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `Reg_id` int(6) NOT NULL,
  `subject` varchar(20) NOT NULL,
  `comment` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `Fname` varchar(15) NOT NULL,
  `Lname` varchar(15) NOT NULL,
  `Contact` char(10) NOT NULL,
  `Company_name` varchar(50) NOT NULL,
  `Email` varchar(45) NOT NULL,
  `Password` varchar(15) NOT NULL,
  `Type` char(1) NOT NULL,
  `Reg_id` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`Fname`, `Lname`, `Contact`, `Company_name`, `Email`, `Password`, `Type`, `Reg_id`) VALUES
('Chintan', 'Gandhi', '9978811646', 'Sayaji Boards', '14bca015.chintan@gmail.com', 'bwChintan', 'V', 20),
('Jill', 'Patel', '9574418220', '', '14bca046.jill@gmail.com', 'london', 'C', 24),
('nuzat', 'pathan', '8511495045', '', '14bca066.nuzat@gmail.com', '066', 'C', 15),
('Amit', 'Patel', '8347777220', 'firstcry.com', 'amitpattel1@gmail.com', 'bwAmit', 'V', 22),
('Admin', 'Admin', '0', '-', 'chintu120012@gmail.com', 'admin', 'A', 12),
('Vijay', 'Gandhi', '9427015755', 'Hollister', 'vijaygandhi68@gmail.com', 'bwVijay', 'V', 23),
('Yash', 'Patel', '8460635478', 'A Plus Cloth Shop', 'yashp610@gmail.com', 'bwYash', 'V', 21);

-- --------------------------------------------------------

--
-- Table structure for table `order_master`
--

CREATE TABLE `order_master` (
  `order_id` int(5) NOT NULL,
  `pro_id` int(5) NOT NULL,
  `size` varchar(30) NOT NULL,
  `Quantity` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_master`
--

INSERT INTO `order_master` (`order_id`, `pro_id`, `size`, `Quantity`) VALUES
(55, 35, 'Medium', '3'),
(55, 27, 'Medium', '2'),
(56, 35, ',Small,Medium', ',10,5'),
(56, 26, ',Medium', ',5');

-- --------------------------------------------------------

--
-- Table structure for table `order_product`
--

CREATE TABLE `order_product` (
  `Order_id` int(5) NOT NULL,
  `Reg_id` int(6) NOT NULL,
  `Total_price` float(8,2) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_product`
--

INSERT INTO `order_product` (`Order_id`, `Reg_id`, `Total_price`, `date`) VALUES
(55, 24, 6252.25, '2017-04-29'),
(56, 20, 71761.25, '2017-04-29');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `Pro_id` int(5) NOT NULL,
  `Cat_id` int(3) NOT NULL,
  `Pro_name` varchar(20) NOT NULL,
  `Pro_size` varchar(25) NOT NULL,
  `Pro_price` float(8,2) NOT NULL,
  `Img_path` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`Pro_id`, `Cat_id`, `Pro_name`, `Pro_size`, `Pro_price`, `Img_path`) VALUES
(25, 1, 'choli', 'Small,Medium,Large', 1205.12, '16images.jpeg,18image.jpeg,20image.jpeg'),
(26, 2, 'Sari', 'Medium,XL', 10000.00, '5image.jpg,6images.jpeg'),
(27, 1, 'Lehnga', 'Medium,Large', 950.00, '10image.jpeg'),
(28, 2, 'Skirt', 'Small,XL', 1500.00, '20image.jpeg'),
(30, 1, 'madrasi sari', 'Large', 10000.00, '5image.jpg'),
(31, 2, 'cotten kurti', 'Small,Large', 1500.00, '19image.jpeg'),
(32, 2, 'pajama', 'Medium', 1200.00, '3c158faa2dd322152dc1a9aabe082091.jpg,5image.jpg,6i'),
(33, 1, 'salvar', 'Medium,Large', 15000.00, '6images.jpeg'),
(35, 4, 'Top', 'Small,Medium,Large', 1450.75, '100.jpeg,101.jpeg,102.jpeg'),
(36, 1, 'Indo western', 'Medium,Large', 1900.00, '100.jpeg'),
(37, 4, 'silk sari', 'XXL', 15000.00, 'trisha-hot-in-saree05.jpeg'),
(38, 2, 'designed choli', 'Medium', 13000.00, 'ir1549_071016_se60161_1.jpeg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`Cat_id`);

--
-- Indexes for table `eventmst`
--
ALTER TABLE `eventmst`
  ADD PRIMARY KEY (`EventId`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`Email`,`Reg_id`),
  ADD UNIQUE KEY `Reg_id` (`Reg_id`),
  ADD UNIQUE KEY `Reg_id_2` (`Reg_id`);

--
-- Indexes for table `order_product`
--
ALTER TABLE `order_product`
  ADD PRIMARY KEY (`Order_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`Pro_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `Cat_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `eventmst`
--
ALTER TABLE `eventmst`
  MODIFY `EventId` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `Reg_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `order_product`
--
ALTER TABLE `order_product`
  MODIFY `Order_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `Pro_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
