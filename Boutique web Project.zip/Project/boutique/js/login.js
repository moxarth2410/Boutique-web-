// JavaScript Document

function Firstname()
{
	var str=document.form1.fname;
	var jstr=/^[A-Za-z]+$/;

	if(str.value.match(jstr))
	{
		document.getElementById('fname').style.backgroundColor="white";
	}
	else
	{
		alert("Name is Not Acceptable");
		document.getElementById('fname').value= null;
		document.getElementById('fname').style.backgroundColor="aqua";
		document.getElementById('fname').focus();
	}
}

function Lastname()
{
	var str=document.form1.lname;
	var jstr=/^[A-Za-z]+$/;

	if(str.value.match(jstr))
	{
		document.getElementById('lname').style.backgroundColor="white";
	}
	else
	{
		alert("Name is Not Acceptable");
		document.getElementById('lname').value= null;
		document.getElementById('lname').style.backgroundColor="aqua";
		document.getElementById('lname').focus();
	}
}

function myEmail(n)
{

	var email=document.form1.Email;
	var jemail=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	
	if(email.value.match(jemail))
	{
		document.getElementById('Email').style.backgroundColor="white";
	}
	else
	{
		alert("Email Address is Not Acceptable");
		document.getElementById('Email').value= null;
		document.getElementById('Email').style.backgroundColor="aqua";
		document.getElementById('Email').focus();
	}
}