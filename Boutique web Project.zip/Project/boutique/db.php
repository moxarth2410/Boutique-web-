<?php
$v_Con = mysqli_connect("localhost","root","","boutique") ;
?>