<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
include("db.php"); 
session_start();
	$v_con=mysqli_connect("localhost","root","","boutique") or die("Connection Failed");
	global $v_session;
	if(isset($_SESSION["Email"]))
	{
		$v_session=$_SESSION["Email"];
	}
?>
<style>
div a {
    text-decoration: none;
    font-size: 20px;
	color:#FFFFFF;
    padding: 15px;
    display:inline-block;
	padding:0px;
}
ul {
  display: inline;
  margin: 0;
  padding: 0;
}
ul li {display: inline-block;}
ul li:hover ul {display: block; }
ul li ul {
  position: absolute;
  display: none;
}
ul li ul li { 
  display: block; 
} 
</style>

<!DOCTYPE HTML>
<html>
<head>
<title>Boutique Website</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery.min.js"></script>
<script type="text/javascript">
        $(document).ready(function() {
            $(".dropdown img.flag").addClass("flagvisibility");

            $(".dropdown dt a").click(function() {
                $(".dropdown dd ul").toggle();
            });
                        
            $(".dropdown dd ul li a").click(function() {
                var text = $(this).html();
                $(".dropdown dt a span").html(text);
                $(".dropdown dd ul").hide();
                $("#result").html("Selected value is: " + getSelectedValue("sample"));
            });
                        
            function getSelectedValue(id) {
                return $("#" + id).find("dt a span.value").html();
            }

            $(document).bind('click', function(e) {
                var $clicked = $(e.target);
                if (! $clicked.parents().hasClass("dropdown"))
                    $(".dropdown dd ul").hide();
            });


            $("#flagSwitcher").click(function() {
                $(".dropdown img.flag").toggleClass("flagvisibility");
            });
        });
     </script>
    <!-- light-box -->
	<script type="text/javascript" src="js/jquery.fancybox.js"></script>
	<link rel="stylesheet" type="text/css" href="css/jquery.fancybox.css" media="screen" />
   <script type="text/javascript">
		$(document).ready(function() {
			/*
			 *  Simple image gallery. Uses default settings
			 */

			$('.fancybox').fancybox();

		});
	</script>
</head>
<body>
	<div class="header">
		<div class="container">
			<div class="row">
			  <div class="col-md-12">
				 <div class="header-left">
					 <div class="logo">
						<a href="index.php"><img src="images/logo.png" alt="" height="50px" width="100px"/></a>
					 </div>
					 <div class="menu">
						  <a class="toggleMenu" href="#"><img src="images/nav.png" alt="" /></a>
						    <ul class="nav" id="nav">
							<?php 
									if(!isset($_SESSION["Email"]))
									{
										header('Location:index.php');
									}	
									else
									{
										$v_query="select Type,Fname from login where Email='".$_SESSION["Email"]."'";
										$v_result=mysqli_query($v_con,$v_query);
						    			$v_data=mysqli_fetch_array($v_result);
										if($v_data[0]=="A")
										{
							?>
										<li><a href="shop.php">Shop</a></li>
										<li><a href="event.php">Event</a></li>
						    			<li><a href="gallery.php">Gallery</a></li>
							    		<li><a href="contact.php">Contact</a></li>
										<li><a href="vender_register.php">Destributor</a></li>
										<li><a href="report.php">Report</a></li>
							<?php
										}
										else
										{
							?>
										<li id="menu"><a href="shop.php">Shop</a></li>
						    			<li id="menu"><a href="event.php">Events</a></li>
						    			<li id="menu"><a href="usergallery.php">Gallery</a></li>
										<li id="menu"><a href="contact.php">Contact</a></li>
										<li id="menu"><a href="feedback.php">feedback</a></li>

										<div class="clear"></div>
							<?php
										}
									}
							?>
							</ul>
							<script type="text/javascript" src="js/responsive-nav.js"></script>
				    </div>							
	    		    <div class="clear"></div>
	    	    </div>
				<div style="float:left;padding-left:300px;">
  					<ul>
    					<li>
							<?php 
								if(!isset($_SESSION["Email"]))
								{
							?>
      						<a href="login.php">Login</a>
							<?php
								}
								else
								{
							?>
							<a href=""><?php echo strtoupper($v_data[1]);?></a>
							<?php
								}
							?>
      						<ul>
							<?php 
								if(isset($_SESSION["Email"]))
								{
								?>
        						<li><a href="logout.php">Logout</a></li>
      						<?php 
								}
							?>
							</ul>
    					</li>
  					</ul>
				</div>
	           
	            <div class="header_right">
	    		  <!-- start search-->
				   <div class="search-box">
							<div id="sb-search" class="sb-search">
								<form method="post" action="shop.php">
									<input class="sb-search-input" placeholder="Enter your search term..." type="search" name="search" id="search">
									<input class="sb-search-submit" type="submit" value="">
									<span class="sb-icon-search"> </span>
								</form>
							</div>
						</div>
						<!----search-scripts---->
						<script src="js/classie.js"></script>
						<script src="js/uisearch.js"></script>
						<script>
							new UISearch( document.getElementById( 'sb-search' ) );
						</script>
				   <?php
						
							$v_que="select Reg_id from login where email='".$_SESSION["Email"]."'";
							$v_result=mysqli_query($v_con,$v_que) or die("Select Query not Valid");
							$v_regid=mysqli_fetch_array($v_result);
							
							$v_query="select * from add_to_cart where Reg_id=".$v_regid[0];
							$v_result1=mysqli_query($v_con,$v_query) or die("Select Query not Valid");
						?>
				    <ul class="icon1 sub-icon1 profile_img">
					 <li><a class="active-icon c1" href="cart.php"> </a>
						<ul class="sub-icon1 list">
						<?php
							while($v_cart=mysqli_fetch_array($v_result1))
							{
							$pro=mysqli_query($v_con,"select * from product where pro_id=".$v_cart[1]);
							$product=mysqli_fetch_array($pro);
							$v_img=explode(",",$product[5]);
						?>
						  <div class="product_control_buttons">
						  		<a href="#"><img src="images/close_edit.png" alt=""/></a>
						  </div>
						  
						   <div class="clear"></div>
						  <li class="list_img"><img src="images/<?php echo $v_img[0];?>" width="50px" height="50px" alt=""/></li>
						  <li class="list_desc"><h4><a href="#"><?php echo $product[2];?></a></h4>RS. <?php echo $product[4];?></span></li>
						  <div class="clear"></div>
					<?php
						}
						
					?>
						</ul>
					 </li>
				   </ul>

		        <div class="clear"></div>
	       </div>
	      </div>
		 </div>
	    </div>
	  </div>
     <di	v class="main">
      <div class="shop_top">
		<div class="container">
			<div class="row ex_box">
				<h3 class="m_2"> Reports </h3>
				<?php
						/*$v_con=mysqli_connect("localhost","root","","boutique") or die("Connection Failed");
						$v_query="select Img_path,pro_price from product where pro_price >= 10000 and pro_price <= 20000";
						$v_result=mysqli_query($v_con,$v_query);
						
						while($v_data=mysqli_fetch_array($v_result))
						{
							$v_data1=explode(",",$v_data[0]);*/
				?>
				<div class="menu">
					<ul class="nav" id="nav" >
						<li><a href="report.php?month=month" name="month" id="month" style="color:#000000;font-size:24px;background-color:#CCCCCC;">Month wise Order</a></li>
						<li><a href="report.php?user=user" name="user" id="user" style="color:#000000;font-size:24px;background-color:#CCCCCC;">Order Per User</a></li>
						<li><a href="report.php?category=category" style="color:#000000;font-size:24px;background-color:#CCCCCC;">Category wise Product</a></li>
					</ul>
				</div>
				<div class="clear"></div>
				<br><br><br>
				<form>
				<div>
				<?php
					if(isset($_GET["month"]))
					{					
				?> 
				
					<select name="mon" id="mon">
						<option value="01">January</option>
						<option value="02">February</option>
						<option value="03">March</option>
						<option value="04">April</option>
						<option value="05">May</option>
						<option value="06">June</option>
						<option value="07">July</option>
						<option value="08">August</option>
						<option value="09">September</option>
						<option value="10">Octomber</option>
						<option value="11">November</option>
						<option value="12">December</option>
					</select>
					<input type="submit" name="submitmon" id="submitmon" >
				<?php
					}
					else if(isset($_GET["user"]))
					{
				?>
					<input type="radio" name="type" id="type" value="C">Customer<br>
					<input type="radio" name="type" id="type" value="V">Distributor
					<input type="submit" name="submittype" id="submittype" >
				<?php
					}
					else
					{
				?>
					<select name="cat" id="cat">
					<?php 
						$v_result=mysqli_query($v_con,"select * from categories");
						while($v_cat=mysqli_fetch_array($v_result))
						{
					?>
						<option value="<?php echo $v_cat[0];?>"><?php echo $v_cat[1];?></option>
					<?php
					}
					?>
					</select>
					<input type="submit" name="submitcat" id="submitcat" >
					<?php
					}
					?>
					
				</div>
				</form>
				<div class="shop_top" style="padding-left:0;margin-left:0;>
		<div class="container" style="padding-left:0;margin-left:50px;>
				<div class="row shop_box-top">
				<?php 
					if(isset($_GET["submittype"]))
					{
					$cnt=0;
						$v_result=mysqli_query($v_con,"select * from login where Type='".$_GET["type"]."'");
						echo '<table style="width:750px;text-align:center;">' ;
						while($v_user=mysqli_fetch_array($v_result))
						{
						
						   $v_pro=mysqli_query($v_con,"select * from order_product where Reg_id=".$v_user[7]);
						   $v_OrderRes=mysqli_fetch_array($v_pro);
						   $v_Row=mysqli_num_rows($v_pro);
						   if($v_Row==0)
						   {
						   }
						   else
						   {
						   
						   echo '<tr><td style="border:1px solid black;padding:10px;font-size:20px;"><b>Order Id</b></td><td style="border:1px solid black;padding:10px;font-size:20px;"><b>Name</b></td><td style="border:1px solid black;padding:10px;font-size:20px;"><b>Email</b></td><td style="border:1px solid black;padding:10px;font-size:20px;"><b>No of Product Purchased</b></td></tr><b>';
							$v_data=mysqli_query($v_con,"select * from order_master where order_id=".$v_OrderRes[0])or die(mysqli_error($v_con));
						   while($v_OrderRes1=mysqli_fetch_array($v_data))
						   {
						        $cnt++;
					        }
							echo '<tr><td style="border:1px solid black;padding:10px;">'.$v_OrderRes[0].'</td><td style="border:1px solid black;padding:10px;">'.$v_user[0].'        '.$v_user[1].'</td><td style="border:1px solid black;padding:10px;">'.$v_user[4].'</td><td style="border:1px solid black;padding:10px;">'.$cnt.'</td></tr>';
							}
						
						}
						echo '</table>';
					}
					else if(isset($_GET["submitmon"]))
					{
					echo '<table style="width:750px;text-align:center;">' ;
					
						$v_result=mysqli_query($v_con,"select Fname,Lname from login where Email='".$_SESSION["Email"]."'");
						$v_name=mysqli_fetch_array($v_result);
						$v_mon=mysqli_query($v_con,"select * from order_product where date_format(date,'%m')='".$_GET["mon"]."'");
						   $v_Row1=mysqli_num_rows($v_mon);
							$v_total_amount = 0 ;
						   if($v_Row1==0)
						   {
						   		echo "No Data Found";
						   }
						   else
						   {
						echo '<tr><td style="border:1px solid black;padding:10px;font-size:20px;"><b>Order Id</b></td><td style="border:1px solid black;padding:10px;font-size:20px;"><b>User Name</b></td><td style="border:1px solid black;padding:10px;font-size:20px;"><b>Total Amount Of Purchase</b></td><td style="border:1px solid black;padding:10px;font-size:20px;"><b>Date of Order</b></td></tr><b>';   
						   while($v_months=mysqli_fetch_array($v_mon))
						   {
						   
						   
							/*$v_data=mysqli_query($v_con,"select * from order_master where order_id=".$v_months[0])or die(mysqli_error($v_con));
						   while($v_data1=mysqli_fetch_array($v_data))
						   {
						        $cnt++;
					        }*/
							echo '<tr><td style="border:1px solid black;padding:10px;">'.$v_months[0].'</td><td style="border:1px solid black;padding:10px;">'.$v_name[0].'     '.$v_name[1].'</td><td style="border:1px solid black;padding:10px;">'.$v_months[2].'</td><td style="border:1px solid black;padding:10px;">'.$v_months[3].'</td></tr>';
							$v_total_amount += $v_months[2];
							}
							echo '<tr><td style="border:1px solid black;padding:10px;font-size:20px;"></td><td style="border:1px solid black;padding:10px;font-size:20px;"><b>Total Amount</b></td><td style="border:1px solid black;padding:10px;font-size:20px;"><b>'.$v_total_amount.'</b></td><td style="border:1px solid black;padding:10px;font-size:20px;"></td></tr><b>';
						
						}
						
						echo '</table>';
					}
					else if(isset($_GET["submitcat"]))
					{
					echo '<table style="width:750px;text-align:center;">' ;
					//echo "select * from order_product where to_char(date,'Mon')='".$_GET["mon"]."'";
						$v_cat=mysqli_query($v_con,"select * from product where cat_id =".$_GET["cat"]);
						   $v_Row1=mysqli_num_rows($v_cat);
						   if($v_Row1==0)
						   {
						   		echo "No Data Found";
						   }
						   else
						   {
						echo '<tr><td style="border:1px solid black;padding:10px;font-size:20px;"><b>Product Name</b></td><td style="border:1px solid black;padding:10px;font-size:20px;"><b>Poduct Size</b></td><td style="border:1px solid black;padding:10px;font-size:20px;"><b>Price</b></td></tr>';   
						   while($v_catg=mysqli_fetch_array($v_cat))
						   {
						   
						   
							/*$v_data=mysqli_query($v_con,"select * from order_master where order_id=".$v_months[0])or die(mysqli_error($v_con));
						   while($v_data1=mysqli_fetch_array($v_data))
						   {
						        $cnt++;
					        }*/
							echo '<tr><td style="border:1px solid black;padding:10px;">'.$v_catg[2].'</td><td style="border:1px solid black;padding:10px;">'.$v_catg[3].'</td><td style="border:1px solid black;padding:10px;">'.$v_catg[4].'</td></tr>';
							//$v_total_amount += $v_months[2];
							}
							
						}
						
						echo '</table>';
					}
					
						?>
				</div>
				</div>
				</div>
		    </div>
		 </div>
	   </div>
	  </div>
	  <div class="footer">
			<div class="container">
				<div class="row">
					<div class="col-md-3">
						<ul class="footer_box">
							<h4>Products</h4>
							<li><a href="#">Mens</a></li>
							<li><a href="#">Womens</a></li>
							<li><a href="#">Youth</a></li>
						</ul>
					</div>
					<div class="col-md-3">
						<ul class="footer_box">
							<h4>About</h4>
							<li><a href="#">Careers and internships</a></li>
							<li><a href="#">Sponserships</a></li>
							<li><a href="#">team</a></li>
							<li><a href="#">Catalog Request/Download</a></li>
						</ul>
					</div>
					<div class="col-md-3">
						<ul class="footer_box">
							<h4>Customer Support</h4>
							<li><a href="#">Contact Us</a></li>
							<li><a href="#">Shipping and Order Tracking</a></li>
							<li><a href="#">Easy Returns</a></li>
							<li><a href="#">Warranty</a></li>
							<li><a href="#">Replacement Binding Parts</a></li>
						</ul>
					</div>
					<div class="col-md-3">
						<ul class="footer_box">
							<h4>Newsletter</h4>
							<div class="footer_search">
				    		   <form>
				    			<input type="text" value="Enter your email" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Enter your email';}">
				    			<input type="submit" value="Go">
				    		   </form>
					        </div>
							<ul class="social">	
							  <li class="facebook"><a href="#"><span> </span></a></li>
							  <li class="twitter"><a href="#"><span> </span></a></li>
							  <li class="instagram"><a href="#"><span> </span></a></li>	
							  <li class="pinterest"><a href="#"><span> </span></a></li>	
							  <li class="youtube"><a href="#"><span> </span></a></li>										  				
						    </ul>
		   				</ul>
					</div>
				</div>
				<div class="row footer_bottom">
				    <div class="copy">
			           <p>© 2014 Template by <a href="http://w3layouts.com" target="_blank">w3layouts</a></p>
		            </div>
					  <dl id="sample" class="dropdown">
				        <dt><a href="#"><span>Change Region</span></a></dt>
				        <dd>
				            <ul>
				                <li><a href="#">Australia<img class="flag" src="images/as.png" alt="" /><span class="value">AS</span></a></li>
				                <li><a href="#">Sri Lanka<img class="flag" src="images/srl.png" alt="" /><span class="value">SL</span></a></li>
				                <li><a href="#">Newziland<img class="flag" src="images/nz.png" alt="" /><span class="value">NZ</span></a></li>
				                <li><a href="#">Pakistan<img class="flag" src="images/pk.png" alt="" /><span class="value">Pk</span></a></li>
				                <li><a href="#">United Kingdom<img class="flag" src="images/uk.png" alt="" /><span class="value">UK</span></a></li>
				                <li><a href="#">United States<img class="flag" src="images/us.png" alt="" /><span class="value">US</span></a></li>
				            </ul>
				         </dd>
	   				  </dl>
   				</div>
			</div>
		</div>
</body>	
</html>