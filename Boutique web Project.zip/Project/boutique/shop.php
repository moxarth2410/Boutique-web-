<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
include("db.php"); 
session_start();
	$v_con=mysqli_connect("localhost","root","","boutique") or die("Connection Failed");
	global $v_session;

if(isset($_GET["cat"]))
{
	$v_cat=$_GET["cat"];
	$v_query="select * from product where Cat_id=".$v_cat;
	$v_type=mysqli_query($v_con,$v_query) or die ("Query not Valid");
}

if(isset($_GET["Confirm"]))
{

$v_que="select Reg_id from login where Email='".$_SESSION["Email"]."'";
$v_result=mysqli_query($v_con,$v_que);
$v_regid=mysqli_fetch_array($v_result);

	$v_query="insert into order_product value(0,".$v_regid[0].",".$_GET["price"].",date_format(NOW(),'%Y-%m-%d'))";
	mysqli_query($v_con,$v_query) or die ("Query not Valid");

$v_queue="select Order_id from order_product where Order_id=".mysqli_insert_id($v_con);
$v_result=mysqli_query($v_con,$v_queue) or die("insert not valid");
$v_orderid=mysqli_fetch_array($v_result);

	$v_q=mysqli_query($v_con,"select * from add_to_cart where Reg_id=".$v_regid[0]) or die ("Query not Valid");
	while($v_order=mysqli_fetch_array($v_q))
	{
	$v_query="insert into order_master value(".$v_orderid[0].",".$v_order[1].",'".$v_order[2]."','".$v_order[3]."')";
	mysqli_query($v_con,$v_query) or die ("Query not Valid");
	}
	header("Location:order_purchase.php?orderid=$v_orderid[0]");

}
?>
<!DOCTYPE HTML>
<html>
<head>
<style>
	
div a {
    text-decoration: none;
    font-size: 20px;
	color:#FFFFFF;
    padding: 15px;
    display:inline-block;
	padding:0px;
}
ul ul {
  display: inline;
  margin: 0;
  padding: 0;
}
ul li {display: inline-block;}
ul li:hover ul {display: block; }
ul li ul {
  position: absolute;
  display: none;
}
ul li ul li { 
  display: block; 
} 
</style>
<title>BOUTIQUE WEBSITE</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery.min.js"></script>
<script type="text/javascript">
        $(document).ready(function() {
            $(".dropdown img.flag").addClass("flagvisibility");

            $(".dropdown dt a").click(function() {
                $(".dropdown dd ul").toggle();
            });
                        
            $(".dropdown dd ul li a").click(function() {
                var text = $(this).html();
                $(".dropdown dt a span").html(text);
                $(".dropdown dd ul").hide();
                $("#result").html("Selected value is: " + getSelectedValue("sample"));
            });
                        
            function getSelectedValue(id) {
                return $("#" + id).find("dt a span.value").html();
            }

            $(document).bind('click', function(e) {
                var $clicked = $(e.target);
                if (! $clicked.parents().hasClass("dropdown"))
                    $(".dropdown dd ul").hide();
            });


            $("#flagSwitcher").click(function() {
                $(".dropdown img.flag").toggleClass("flagvisibility");
            });
        });
		var v_Size=[];
		
		function DisplayPage(v_Val,v_Array)
		{document.getElementById("form1").submit();
		}
     </script>
</head>
<body>
	<div class="header">
		<div class="container">
			<div class="row">
			  <div class="col-md-12">
				 <div class="header-left">
					 <div class="logo">
						<a href="index.php"><img src="images/logo.png" alt="" height="50px" width="100px"/></a>
					 </div>
					 <div class="menu" style="margin:0px;padding:0px;">
						  
						    <ul class="nav" id="nav">
							<?php 
									if(!isset($_SESSION["Email"]))
									{
										header('Location:index.php');
									}	
									else
									{
										$v_query="select Type,Fname from login where Email='".$_SESSION["Email"]."'";
										
										$v_result=mysqli_query($v_con,$v_query);
						    			$v_data=mysqli_fetch_array($v_result);
										if($v_data[0]=="A")
										{
							?>
										<li><a href="shop.php">Shop</a></li>
										<li><a href="event.php">Event</a></li>
						    			<li><a href="gallery.php">Gallery</a></li>
							    		<li><a href="contact.php">Contact</a></li>
										<li><a href="vender_register.php">Destributor</a></li>
										<li><a href="report.php">Report</a></li>
							<?php
										}
										else
										{
							?>
										<li id="menu"><a href="shop.php">Shop</a></li>
						    			<li id="menu"><a href="event.php">Events</a></li>
						    			<li id="menu"><a href="usergallery.php">Gallery</a></li>
										<li id="menu"><a href="contact.php">Contact</a></li>
										<li id="menu"><a href="feedback.php">feedback</a></li>

										<div class="clear"></div>
							<?php
										}
									}
							?>
							</ul>
							<script type="text/javascript" src="js/responsive-nav.js"></script>
				    </div>							
				</div>	           
	   				<div style="float:left;padding-left:250px;">
  					<ul>
    					<li>
							<?php 
								if(!isset($_SESSION["Email"]))
								{
							?>
      						<a href="login.php">Login</a>
							<?php
								}
								else
								{
							?>
							<a href=""><?php echo strtoupper($v_data[1]);?></a>
							<?php
								}
							?>
      						<ul>
							<?php 
								if(isset($_SESSION["Email"]))
								{
								?>
        						<li><a href="logout.php">Logout</a></li>
      						<?php 
								}
							?>
							</ul>
    					</li>
  					</ul>
				</div>
				<div class="header_right">
	    		  <!-- start search-->
				  
				  <div class="search-box">
							<div id="sb-search" class="sb-search">
								<form method="post" action="shop.php">
									<input class="sb-search-input" placeholder="Enter your search term..." type="search" name="search" id="search">
									<input class="sb-search-submit" type="submit" value="">
									<span class="sb-icon-search"> </span>
								</form>
							</div>
						</div>
						<!----search-scripts---->
						<script src="js/classie.js"></script>
						<script src="js/uisearch.js"></script>
						<script>
							new UISearch( document.getElementById( 'sb-search' ) );
						</script>
<?php
						
							$v_que="select Reg_id from login where email='".$_SESSION["Email"]."'";
							$v_result=mysqli_query($v_con,$v_que) or die("Select Query not Valid");
							$v_regid=mysqli_fetch_array($v_result);
							
							$v_query="select * from add_to_cart where Reg_id=".$v_regid[0];
							$v_result1=mysqli_query($v_con,$v_query) or die("Select Query not Valid");
						?>
				    <ul class="icon1 sub-icon1 profile_img">
					 <li><a class="active-icon c1" href="cart.php"> </a>
						<ul class="sub-icon1 list">
						<?php
							while($v_cart=mysqli_fetch_array($v_result1))
							{
							$pro=mysqli_query($v_con,"select * from product where pro_id=".$v_cart[1]);
							$product=mysqli_fetch_array($pro);
							$v_img=explode(",",$product[5]);
						?>
						  <div class="product_control_buttons">
						  		<a href="#"><img src="images/close_edit.png" alt=""/></a>
						  </div>
						  
						   <div class="clear"></div>
						  <li class="list_img"><img src="images/<?php echo $v_img[0];?>" width="50px" height="50px" alt=""/></li>
						  <li class="list_desc"><h4><a href="#"><?php echo $product[2];?></a></h4>RS. <?php echo $product[4];?></span></li>
						  <div class="clear"></div>
					<?php
						}
						
					?>
						</ul>
					 </li>
				   </ul>
		        <div class="clear"></div>
	       </div>
	      </div>
		 </div>
	    </div>
	  </div>

      <div class="shop_top" style="padding-left:0;margin-left:0;">
		<div class="container" style="padding-left:0;margin-left:50px;">
			<div class="row shop_box-top" style="float:left;position:relative;width:15%;margin:5px; background-color:#CCCCCC">
				<div>
					<form action="" method="post" name="form1" id="form1">
					<table>
					<tr>
						<td>
					<span style="background-color:#CCCCCC;size:100px;"><b>Price :</b></span><br><br>
								<input type="text" name="lowprice" size="5" placeholder="Lower"> TO					</span><span>
                        		<input type="text" name="highprice" size="5" placeholder="Higher">
                        		</span><br>
								<input type="submit" name="price" value="Price">
							</td>
						</tr>
						<tr>
							<td>
								</br></br>
							</td>
						</tr>
					<tr>
						<td>
					<span style="background-color:#CCCCCC">Product Type</span>
					<span>
						</td>
					</tr>
					
					<?php
						$v_query="select Cat_name,Cat_id from Categories";
						$v_result=mysqli_query($v_con,$v_query);
						while($v_data=mysqli_fetch_array($v_result))
						{
					?>	
						<tr>
							<td>
						<input type="radio" name="ptype" value="<?php echo $v_data[1];?>"><?php echo $v_data[0]; ?>
							</td>
						</tr>
						
					<?php
						}
					?>
					<tr><td>
					<input type="submit" name="type" value="Type"></td></tr>	
					</span>
					<tr>
							<td>
								</br></br>
							</td>
						</tr>
						</td>
					</tr>
					</br>
					</br>
					<tr>
						<td>
					
					<span style="background-color:#CCCCCC">Product Size</span><br>
					<span>
						<input type="radio" name="size1" value="Small">Small<br>
						<input type="radio" name="size1" value="Medium"  >Medium<br>
						<input type="radio" name="size1" value="Large" >Large<br>
						<input type="radio" name="size1" value="XL"  >XL<br>
						<input type="radio" name="size1" value="XXL" >XXL<br>
					</span>	
					<input type="submit" name="size" value="Size">
						</td>
					</tr>
					<tr><td><br></td></tr>
					<tr>
						<td>
							</td>
					</tr>
			</table>
				</form>
				</div>
			</div>
			<div class="row shop_box-top" style="float:right;position:relative;width:85%;">
				<?php
					if(isset($_POST["search"]))
					{
					$v_Search=$_POST["search"];
					
					$v_query="select Cat_Id,Product.Pro_id,Product.Pro_name,Product.Pro_price,Product.Img_path from Product where Pro_name like '%".$v_Search."%'";
					$v_items=mysqli_query($v_con,$v_query);
					while($v_data=mysqli_fetch_array($v_items))
					{
						$v_arr=$v_data[4];
						$v_img=explode(",",$v_arr);
				?>
					<div class="col-md-3 shop_box">
								<a href="single.php?pid=<?php echo $v_data[0];?>">
									<img src="images/<?php echo $v_img[0]; ?>" style="height:300px;" class="img-responsive" alt="imag" usemap="#mapping"/>
									<span class="new-box">
										<span class="new-label">New</span>
									</span>
									<span class="sale-box">
										<span class="sale-label">Sale!</span>
									</span>
									<div class="shop_desc">
										<h3>
											<a href="single.php?pid=<?php echo $v_data[0];?>"><?php echo $v_data[2]; ?> </a>
										</h3>
										<p>RS. <?php echo $v_data[3];?> </p>
										<!--<span class="reducedfrom">$66.00</span>
										<span class="actual"></span><br>-->
										<ul class="buttons">
											<li class="shop_btn"><a href="single.php?pid=<?php echo $v_data[0];?>">Read More</a></li>
											<div class="clear"> </div>
										</ul>
				    				</div>
			  					</a>
							</div>
				<?php
					}
					}
					else
					{
						if(isset($_POST["price"]))
						{
							$v_query="select * from product where Pro_price>=".$_POST["lowprice"]." && Pro_price<=".$_POST["highprice"] ;
						}
						else if(isset($_POST["type"]))
						{
							
								$v_query="select * from product where Cat_id=".$_POST["ptype"];
							
						}
						else if(isset($_POST["size"]))
						{
								$v_query="select * from product where Pro_size like '%".$_POST["size1"]."%'";
						}
						else
						{
							$v_query="select * from product";
						}
						$result1=mysqli_query($v_con,$v_query);
						while($v_data=mysqli_fetch_array($result1))
						{
							$v_arr=$v_data[5];
							$v_img=explode(",",$v_arr);
				?>
							<div class="col-md-3 shop_box">
								<a href="single.php?pid=<?php echo $v_data[0];?>">
									<img src="images/<?php echo $v_img[0]; ?>" style="height:300px;" class="img-responsive" alt="imag" usemap="#mapping"/>
									<span class="new-box">
										<span class="new-label">New</span>
									</span>
									<span class="sale-box">
										<span class="sale-label">Sale!</span>
									</span>
									<div class="shop_desc">
										<h3>
											<a href="single.php?pid=<?php echo $v_data[0];?>"><?php echo $v_data[2]; ?> </a>
										</h3>
										<p>RS. <?php echo $v_data[4];?> </p>
										<!--<span class="reducedfrom">$66.00</span>
										<span class="actual"><?php echo "$".$v_data[3]; ?></span><br>-->
										<ul class="buttons">
											<li class="shop_btn"><a href="single.php?pid=<?php echo $v_data[0];?>">Read More</a></li>
											<div class="clear"> </div>
										</ul>
				    				</div>
			  					</a>
							</div>	
			<?php
				}
				}
			?>
			</div>
		 </div>
	   </div>
	  <div class="footer">
			<div class="container">
				<div class="row">
					<div class="col-md-3">
						<ul class="footer_box">
							<h4>Products</h4>
							<li><a href="#">Mens</a></li>
							<li><a href="#">Womens</a></li>
							<li><a href="#">Youth</a></li>
						</ul>
					</div>
					<div class="col-md-3">
						<ul class="footer_box">
							<h4>About</h4>
							<li><a href="#">Careers and internships</a></li>
							<li><a href="#">Sponserships</a></li>
							<li><a href="#">team</a></li>
							<li><a href="#">Catalog Request/Download</a></li>
						</ul>
					</div>
					<div class="col-md-3">
						<ul class="footer_box">
							<h4>Customer Support</h4>
							<li><a href="#">Contact Us</a></li>
							<li><a href="#">Shipping and Order Tracking</a></li>
							<li><a href="#">Easy Returns</a></li>
							<li><a href="#">Warranty</a></li>
							<li><a href="#">Replacement Binding Parts</a></li>
						</ul>
					</div>
					<div class="col-md-3">
						<ul class="footer_box">
							<h4>Newsletter</h4>
							<div class="footer_search">
				    		   <form>
				    			<input type="text" value="Enter your email" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Enter your email';}">
				    			<input type="submit" value="Go">
				    		   </form>
					        </div>
							<ul class="social">	
							  <li class="facebook"><a href="#"><span> </span></a></li>
							  <li class="twitter"><a href="#"><span> </span></a></li>
							  <li class="instagram"><a href="#"><span> </span></a></li>	
							  <li class="pinterest"><a href="#"><span> </span></a></li>	
							  <li class="youtube"><a href="#"><span> </span></a></li>										  				
						    </ul>
		   					
						</ul>
					</div>
				</div>
				<div class="row footer_bottom">
				    <div class="copy">
			           <p>© 2014 Template by <a href="http://w3layouts.com" target="_blank">w3layouts</a></p>
		            </div>
					  <dl id="sample" class="dropdown">
				        <dt><a href="#"><span>Change Region</span></a></dt>
				        <dd>
				            <ul>
				                <li><a href="#">Australia<img class="flag" src="images/as.png" alt="" /><span class="value">AS</span></a></li>
				                <li><a href="#">Sri Lanka<img class="flag" src="images/srl.png" alt="" /><span class="value">SL</span></a></li>
				                <li><a href="#">Newziland<img class="flag" src="images/nz.png" alt="" /><span class="value">NZ</span></a></li>
				                <li><a href="#">Pakistan<img class="flag" src="images/pk.png" alt="" /><span class="value">Pk</span></a></li>
				                <li><a href="#">United Kingdom<img class="flag" src="images/uk.png" alt="" /><span class="value">UK</span></a></li>
				                <li><a href="#">United States<img class="flag" src="images/us.png" alt="" /><span class="value">US</span></a></li>
				            </ul>
				         </dd>
	   				  </dl>
   				</div>
			</div>
			</div>
</body>	
</html>